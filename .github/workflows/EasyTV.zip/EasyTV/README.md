# EasyTV (Android TV)

1. Отворете папката в Android Studio (File > Open) и изчакайте Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk
4. Инсталация на ТВ: `adb connect <IP-на-ТВ>` и `adb install app-debug.apk`
   (или през флашка / Send Files to TV).

Адресът се сменя в MainActivity.kt (променлива `url`).
Бутони: стрелки – преместване между елементите (с рамка), OK – избор, при видео ляво/дясно ±10 сек, Назад – назад/изход, Menu или червен – презареждане.
