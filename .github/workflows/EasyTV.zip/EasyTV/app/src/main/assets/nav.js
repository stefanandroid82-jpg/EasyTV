(function () {
  if (window.__easytvNav) return;
  window.__easytvNav = true;

  var st = document.createElement('style');
  st.textContent =
    '.easytv-focus{outline:4px solid #00B4D8 !important;outline-offset:2px !important;' +
    'box-shadow:0 0 14px 4px rgba(0,180,216,.7) !important;border-radius:4px;}' +
    '*:focus{outline:none;}';
  document.head.appendChild(st);

  var SEL = 'a[href],button,input:not([type=hidden]),select,textarea,summary,' +
    '[tabindex]:not([tabindex="-1"]),[onclick],[role=button],[role=link],[role=tab],' +
    '[role=menuitem],[role=option],video,.btn,.channel,.card,li[data-id]';
  var cur = null;

  function visible(el) {
    var r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return false;
    var cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.pointerEvents === 'none') return false;
    if (el.disabled) return false;
    return r.bottom > -2000 && r.top < innerHeight + 2000;
  }

  function candidates() {
    var all = document.querySelectorAll(SEL), out = [];
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (visible(el)) {
        // skip wrappers that contain other focusable items (keep leaves)
        var inner = el.querySelector && el.tagName !== 'VIDEO' && el.tagName !== 'SELECT'
          ? el.querySelector('a[href],button,input,select,textarea') : null;
        if (inner && inner !== el && visible(inner)) continue;
        out.push(el);
      }
    }
    return out;
  }

  function center(r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }

  function setFocus(el) {
    if (cur) cur.classList.remove('easytv-focus');
    cur = el;
    if (!el) return;
    el.classList.add('easytv-focus');
    try { el.focus({ preventScroll: true }); } catch (e) {}
    try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
  }

  function inViewFirst(list) {
    var best = null, bd = 1e9;
    list.forEach(function (el) {
      var r = el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight) return;
      var d = r.top * 3 + r.left;
      if (d < bd) { bd = d; best = el; }
    });
    return best || list[0] || null;
  }

  function move(dir) {
    var list = candidates();
    if (!list.length) { scrollBy(dir === 'left' ? -300 : dir === 'right' ? 300 : 0,
                                 dir === 'up' ? -300 : dir === 'down' ? 300 : 0); return; }
    if (!cur || !document.contains(cur) || !visible(cur)) { setFocus(inViewFirst(list)); return; }

    var cr = cur.getBoundingClientRect(), cc = center(cr), best = null, bs = 1e12;
    list.forEach(function (el) {
      if (el === cur) return;
      var r = el.getBoundingClientRect(), c = center(r), dx = c.x - cc.x, dy = c.y - cc.y, p, s;
      if (dir === 'right') { if (r.left < cr.right - cr.width * 0.5 && dx <= 4) return; p = dx; s = Math.abs(dy); }
      else if (dir === 'left') { if (r.right > cr.left + cr.width * 0.5 && dx >= -4) return; p = -dx; s = Math.abs(dy); }
      else if (dir === 'down') { if (r.top < cr.bottom - cr.height * 0.5 && dy <= 4) return; p = dy; s = Math.abs(dx); }
      else { if (r.bottom > cr.top + cr.height * 0.5 && dy >= -4) return; p = -dy; s = Math.abs(dx); }
      if (p <= 0) return;
      var score = p + s * 2.5;
      if (score < bs) { bs = score; best = el; }
    });

    if (best) { setFocus(best); }
    else if (dir === 'up' || dir === 'down') { scrollBy(0, dir === 'up' ? -300 : 300); }
    else { scrollBy(dir === 'left' ? -300 : 300, 0); }
  }

  function isText(el) {
    if (!el) return false;
    if (el.tagName === 'TEXTAREA') return true;
    if (el.tagName !== 'INPUT') return false;
    return /^(text|search|email|url|tel|password|number|)$/i.test(el.type || '');
  }

  function activate(el) {
    if (!el) return;
    if (el.tagName === 'VIDEO') { el.paused ? el.play() : el.pause(); return; }
    el.click();
  }

  document.addEventListener('keydown', function (e) {
    var k = e.keyCode, dir = null;
    if (k === 37) dir = 'left'; else if (k === 38) dir = 'up';
    else if (k === 39) dir = 'right'; else if (k === 40) dir = 'down';

    var ae = document.activeElement;
    if (dir && isText(ae) && (dir === 'left' || dir === 'right')) return; // edit text normally

    if (dir) {
      // seek when a video is focused
      if (cur && cur.tagName === 'VIDEO' && (dir === 'left' || dir === 'right')) {
        cur.currentTime += dir === 'left' ? -10 : 10;
        e.preventDefault(); e.stopPropagation(); return;
      }
      move(dir);
      e.preventDefault(); e.stopPropagation();
    } else if (k === 13 || k === 23 || k === 66) {
      if (isText(ae) && ae !== cur) return;
      if (cur && document.contains(cur)) {
        activate(cur);
        e.preventDefault(); e.stopPropagation();
      }
    } else if (k === 427 || k === 33) { scrollBy(0, -innerHeight * 0.8); }   // CH+ / PgUp
    else if (k === 428 || k === 34) { scrollBy(0, innerHeight * 0.8); }    // CH- / PgDn
    else if (k === 415 || k === 179) {                                        // play/pause
      var v = document.querySelector('video');
      if (v) { v.paused ? v.play() : v.pause(); e.preventDefault(); }
    }
  }, true);

  // initial focus once the page has content
  setTimeout(function () {
    var l = candidates();
    if (l.length && !cur) setFocus(inViewFirst(l));
  }, 600);
})();
